import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp
 
import units as u
import pysindy as ps
import pysr
from scipy.ndimage import gaussian_filter, convolve
from scipy.signal import hilbert, chirp

# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Seed the random number generators for reproducibility
# np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
file_name = '/data/Dropbox/MATLAB_for_Baslisk/msk_database_DB_0d06_smooth0_081123-1958.mat'
Brek = loadmat(file_name)
x = np.ravel(Brek['x1'])
time_wrong = np.ravel(Brek['time_vec'])
length_strp = len(time_wrong)
id_s = np.argsort(time_wrong[:length_strp])

t = np.linspace(0,time_wrong[-1],len(time_wrong))

u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])
T = 1.091;
omega= 2*np.pi/T;

def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u1 = np.real(u_nested[0][0])
    return u1
def grad1(in1, h):
    """
    This function takes the gradient in the x direction. h is the spatial step.
    """
    out1 = np.zeros_like(in1)
    noy1, nox1 = in1.shape
    in_ = np.zeros((noy1, nox1 + 4))
    noyz, noxz = in_.shape
    
    in_[:, 0] = in1[:, nox1 - 2]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 1] = in1[:, nox1 - 1]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 2:nox1 + 2] = in1
    in_[:, noxz - 2] = in_[:, 1]
    in_[:, noxz - 1] = in_[:, 0]
    
    out_ = np.zeros_like(in_)
    out_[:, 2:noxz - 2] = (-in_[:, 0:noxz - 4] + 8 * in_[:, 1:noxz - 3] - 8 * in_[:, 3:noxz - 1] + in_[:, 4:noxz]) / (12 * h)
    out1 = out_[:, 2:nox1 + 2]
    
    return out1





u_in = Brek['u_in'];

tar_eta_t = Brek['tar_eta_t'];


print('Data Loading and success\n')



objective = """

function default_objective(tree, dataset::Dataset{T,L}, options, idx)::L where {T,L}
    (prediction, completion) = eval_tree_array(tree, dataset.X, options)
    if !completion
        return L(Inf)
    end

    

    diffs = .- dataset.y .* log(prediction+ 1e-7)  .- (1 .- dataset.y) .* log(1 .- prediction+ 1e-7)

    return sum(diffs) ./ length(diffs)
end

"""
#   prediction1 = round.(1 ./ (1 .+ (exp.(prediction))) .- 0.01)



model_real = pysr.PySRRegressor(binary_operators=["+", "*" , "/"],
 #                               unary_operators=["soft_max(x) = round(1/1+exp(x)-0.01)"],
 #                               extra_sympy_mappings={'soft_max': lambda x: round(1 / ( 1 - 0.01 ))},
                                maxsize = 20, 
                                populations=1000,
                                ncyclesperiteration = 5000,
                                model_selection='best',
                                loss="L2HingeLoss()",
                                batching=True
                                )
model_real.fit(u_in,np.real(tar_eta_t))
print('DATABASE_Train Full Objective Loss: Class add_k is \n')
print(file_name + '\n')
print(model_real.get_best().equation)



# Plot u and u_dot
'''plt.figure()
plt.pcolormesh(t, x, u)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.figure()

plt.pcolormesh(t, x, u_dot)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''
