import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp

import pysindy as ps
import pysr

# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Seed the random number generators for reproducibility
# np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
Brek = loadmat('/data/Dropbox/MATLAB_for_Baslisk/test_BK_0d20_1d34_bak_surf')
x = np.ravel(Brek['x_out'])
time_wrong = np.ravel(Brek['time_vec'])

t = np.linspace(0,time_wrong[-1],len(time_wrong))

u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])


def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u = np.real(u_nested[0][0])
    return u


uy = load_var(Brek,'uy');
dudx = load_var(Brek,'dud_x');
dudy = load_var(Brek,'dud_y');
dudx = load_var(Brek,'dud_x');
dudy = load_var(Brek,'dud_y');
dwdx = load_var(Brek,'dwd_x');
dwdy = load_var(Brek,'dwd_y');
eta = load_var(Brek,'eta');
dt = t[1] - t[0]
dx = x[1] - x[0]
eta_x = ps.SmoothedFiniteDifference(axis=1,smoother_kws={'window_length': 20})._differentiate(eta, t = -dx)

eta_t = ps.SmoothedFiniteDifference(axis=0,smoother_kws={'window_length': 20})._differentiate(eta, t = -dt)
plt.figure()
plt.pcolormesh(t, x, eta_t)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.colorbar();
plt.figure()
diff = eta_x*ux+uy+uy*eta_x*eta_x-eta_t
plt.pcolormesh(t, x,diff)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.colorbar();
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()

num_data_points=eta_x.shape[0]*eta_x.shape[1]

u_in = np.zeros((num_data_points, 3))
u_in [:,0] = np.reshape((eta_x),num_data_points)
u_in [:,1] = np.reshape((uy),num_data_points)
u_in [:,2] = np.reshape((ux) ,num_data_points)

tar_eta_t = np.reshape(eta_t,num_data_points)
model_real = pysr.PySRRegressor(binary_operators=["+", "*"],complexity_of_operators={"*": 4}, maxsize = 17, batching=True)
model_real.fit(u_in,np.real(tar_eta_t))
print(model_real)



# Plot u and u_dot
'''plt.figure()
plt.pcolormesh(t, x, u)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.figure()

plt.pcolormesh(t, x, u_dot)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''
