import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp
 
import units as u
import pysindy as ps
import pysr
from scipy.ndimage import gaussian_filter, convolve
from scipy.signal import hilbert, chirp

from gplearn.genetic import SymbolicClassifier
import graphviz
from matplotlib.colors import ListedColormap
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_moons, make_circles, make_classification
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn.metrics import roc_auc_score
from sklearn.datasets import load_breast_cancer
from sklearn.utils import check_random_state


integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
file_name = '/data/Dropbox/MATLAB_for_Baslisk/msk_database_0d06_smooth0_281023-1608.mat'
Brek = loadmat(file_name)
x = np.ravel(Brek['x1'])
time_wrong = np.ravel(Brek['time_vec'])
length_strp = len(time_wrong)
id_s = np.argsort(time_wrong[:length_strp])

t = np.linspace(0,time_wrong[-1],len(time_wrong))

u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])
T = 1.091;
omega= 2*np.pi/T;

def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u1 = np.real(u_nested[0][0])
    return u1
def grad1(in1, h):
    """
    This function takes the gradient in the x direction. h is the spatial step.
    """
    out1 = np.zeros_like(in1)
    noy1, nox1 = in1.shape
    in_ = np.zeros((noy1, nox1 + 4))
    noyz, noxz = in_.shape
    
    in_[:, 0] = in1[:, nox1 - 2]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 1] = in1[:, nox1 - 1]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 2:nox1 + 2] = in1
    in_[:, noxz - 2] = in_[:, 1]
    in_[:, noxz - 1] = in_[:, 0]
    
    out_ = np.zeros_like(in_)
    out_[:, 2:noxz - 2] = (-in_[:, 0:noxz - 4] + 8 * in_[:, 1:noxz - 3] - 8 * in_[:, 3:noxz - 1] + in_[:, 4:noxz]) / (12 * h)
    out1 = out_[:, 2:nox1 + 2]
    
    return out1


u_in = Brek['u_in'];

tar_eta_t = Brek['tar_eta_t'];

print('Data Loading and success\n')


rng = check_random_state(0)

est = SymbolicClassifier(parsimony_coefficient=.01,
                         n_jobs=12,
                         random_state=1,
                         )
est.fit(u_in,np.real(tar_eta_t))


y_true = np.real(tar_eta_t)[1700000:]
y_score = est.predict_proba(u_in[1700000:])[:,1]
roc_auc_score(y_true, y_score)

dot_data = est._program.export_graphviz()
graph = graphviz.Source(dot_data)
graph.render('images/ex4_tree', format='png', cleanup=True)
graph
