import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp
 
import units as u
import pysindy as ps
import pysr
from scipy.ndimage import gaussian_filter, convolve
from scipy.signal import hilbert, chirp

# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)
import mat73
# Seed the random number generators for reproducibility
# np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
Brek = mat73.loadmat('/data/Dropbox/KdV_find/shape_avg_near_focus_v7_expand_lib.mat')
'''x = np.ravel(Brek['x_vec'])

T = 1.091;
omega= 2*np.pi/T;'''

def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u1 = np.real(u_nested[0][0])
    return u1
def grad1(in1, h):
    """
    This function takes the gradient in the x direction. h is the spatial step.
    """
    out1 = np.zeros_like(in1)
    noy1, nox1 = in1.shape
    in_ = np.zeros((noy1, nox1 + 4))
    noyz, noxz = in_.shape
    
    in_[:, 0] = in1[:, nox1 - 2]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 1] = in1[:, nox1 - 1]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 2:nox1 + 2] = in1
    in_[:, noxz - 2] = in_[:, 1]
    in_[:, noxz - 1] = in_[:, 0]
    
    out_ = np.zeros_like(in_)
    out_[:, 2:noxz - 2] = (-in_[:, 0:noxz - 4] + 8 * in_[:, 1:noxz - 3] - 8 * in_[:, 3:noxz - 1] + in_[:, 4:noxz]) / (12 * h)
    out1 = out_[:, 2:nox1 + 2]
    
    return out1

jl = pysr.julia_helpers.init_julia(julia_kwargs={"threads": 32, "optimize": 3})

jl.eval("""
    import Statistics
""" ); 
objective = """

function default_objective(tree, dataset::Dataset{T,L}, options, idx)::L where {T,L}
    (prediction, completion) = eval_tree_array(tree, dataset.X, options)
    if !completion
        return L(Inf)
    end

    # Create array to store whether feature was used:
    was_feature_used = zeros(Bool, dataset.nfeatures)

    # Loop through nodes in tree:
    foreach(tree) do node
        if node.degree == 0 && !(node.constant)
            was_feature_used[node.feature] = true
        end
    end

    number_features_used = sum(was_feature_used)

    if number_features_used < 1
        return L(Inf)
    end

    num_space = 2048
    num_time = 8
    num_case = 50

    prediction =  dataset.y - prediction

    if abs(sum(prediction)/sum(y)) > 100 
        return L(Inf)
    end

    prediction = reshape(prediction, num_space, num_time, num_case )
    y_std = reshape(dataset.y, num_space, num_time, num_case )
    y_std = sum(y_std, dims=(1))
    y_std = reshape(y_std, num_time, num_case )



    I = sum(prediction, dims=(1))
    I = reshape(I, num_time, num_case )
    I = diff(abs.(I), dims=(1))./sum(abs.(y_std), dims=(1))*num_time;
    I = sum(sum(I.^2))

    return (I) 
end

"""

u_in = Brek['u_mat'];

tar_eta_t = Brek['u_tar'];
tar_eta_t = tar_eta_t.reshape((u_in.shape[0], 1));
print('Data Loading and success\n')

model_real = pysr.PySRRegressor(binary_operators=["+", "*", "-"], 
                                complexity_of_operators={"+": 1}, 
                                maxsize = 30, 
                                batching=True,
                                populations=120,
                                population_size=57,
                                ncyclesperiteration = 5000,
                                )
model_real.fit(u_in,np.real(tar_eta_t))
print('shape_avg_near_focus_v5\n')
print(model_real.get_best().equation)



# Plot u and u_dot
'''plt.figure()
plt.pcolormesh(t, x, u)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.figure()

plt.pcolormesh(t, x, u_dot)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''
