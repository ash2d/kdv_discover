import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp

import pysindy as ps

# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Seed the random number generators for reproducibility
np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
Brek = loadmat('/data/Dropbox/MATLAB_for_Baslisk/test_BK_0d23_1d34_bak_surf')
x = np.ravel(Brek['x_out'])
time_wrong = np.ravel(Brek['time_vec'])
length_strp = len(time_wrong)
id_s = np.argsort(time_wrong[:length_strp])

t = np.linspace(0,time_wrong[-1],len(time_wrong))

u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])


def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u = np.real(u_nested[0][0])
    return u


uy = load_var(Brek,'uy');
dudx = load_var(Brek,'dud_x');
dudy = load_var(Brek,'dud_y');
dudx = load_var(Brek,'dud_x');
dudy = load_var(Brek,'dud_y');
dwdx = load_var(Brek,'dwd_x');
dwdy = load_var(Brek,'dwd_y');
eta = load_var(Brek,'eta');

eta[:, :length_strp] = eta[:, id_s]
ux[:, :length_strp] = ux[:, id_s]
uy[:, :length_strp] = uy[:, id_s]
dudx[:, :length_strp] = dudx[:, id_s]
dudy[:, :length_strp] = dudy[:, id_s]
dudx[:, :length_strp] = dudx[:, id_s]
dudy[:, :length_strp] = dudy[:, id_s]
dwdx[:, :length_strp] = dwdx[:, id_s]
dwdy[:, :length_strp] = dwdy[:, id_s]


dt = t[1] - t[0]
dx = x[1] - x[0]
eta_x= ps.FiniteDifference(axis=0)._differentiate(eta, t = dx)
u_in = np.zeros((uy.shape[0],451, 4))
u_in [:,0:450,0] = eta[:,0:450]
u_in [:,0:450,1] = ux[:,0:450]
u_in [:,0:450,2] = uy[:,0:450]
u_in [:,0:450,3] = eta_x[:,0:450]




# Plot u and u_dot
'''plt.figure()
plt.pcolormesh(t, x, u)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.figure()

plt.pcolormesh(t, x, u_dot)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''



# u_dot = u_dot.reshape(len(x), len(t), 1)

feature_names = [" eta", " ux", " uy",'etax'];

library_functions = [lambda x: x, lambda x, y: x * y , lambda x, y: x * y * y]
library_function_names = [lambda x: x , lambda  x, y: x + y , lambda  x, y: x + y + y]
pde_lib_single_terms = ps.PDELibrary(
    library_functions=library_functions,
    function_names=library_function_names,
    derivative_order=0,
    is_uniform=True,
).fit([u_in])

print("Original input library: ")
print(pde_lib_single_terms.get_feature_names())


pde_lib=pde_lib_single_terms


print('STLSQ model: ')
optimizer = ps.STLSQ(threshold=2, alpha=1e-5, normalize_columns=True)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SR3 model, L0 norm: ')
optimizer = ps.SR3(
    threshold=2,
    max_iter=10000,
    tol=1e-15,
    nu=1e2,
    thresholder="l0",
    normalize_columns=True,
)

model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SR3 model, L1 norm: ')
optimizer = ps.SR3(
    threshold=0.5, max_iter=10000, tol=1e-15,
    thresholder="l1", normalize_columns=True
)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SSR model: ')
optimizer = ps.SSR(normalize_columns=True, kappa=1)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SSR (metric = model residual) model: ')
optimizer = ps.SSR(criteria="model_residual",
                   normalize_columns=True,
                   kappa=1)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('FROLs model: ')
optimizer = ps.FROLS(normalize_columns=True, kappa=1e-3)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()


