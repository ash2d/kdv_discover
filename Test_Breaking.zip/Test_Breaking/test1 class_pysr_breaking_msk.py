import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp
from scipy.signal import hilbert, chirp

import units as u
import pysindy as ps
import pysr
from scipy.ndimage import gaussian_filter, convolve

# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Seed the random number generators for reproducibility
# np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
Brek = loadmat('/data/Dropbox/MATLAB_for_Baslisk/test_BK_0d22_1d42_bak_surf2_pert')
x = np.ravel(Brek['x1'])
time_wrong = np.ravel(Brek['time_vec'])
length_strp = len(time_wrong)
id_s = np.argsort(time_wrong[:length_strp])

t = np.linspace(0,time_wrong[-1],len(time_wrong))

u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])


def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u1 = np.real(u_nested[0][0])
    return u1
def grad1(in1, h):
    """
    This function takes the gradient in the x direction. h is the spatial step.
    """
    out1 = np.zeros_like(in1)
    noy1, nox1 = in1.shape
    in_ = np.zeros((noy1, nox1 + 4))
    noyz, noxz = in_.shape
    
    in_[:, 0] = in1[:, nox1 - 2]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 1] = in1[:, nox1 - 1]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 2:nox1 + 2] = in1
    in_[:, noxz - 2] = in_[:, 1]
    in_[:, noxz - 1] = in_[:, 0]
    
    out_ = np.zeros_like(in_)
    out_[:, 2:noxz - 2] = (-in_[:, 0:noxz - 4] + 8 * in_[:, 1:noxz - 3] - 8 * in_[:, 3:noxz - 1] + in_[:, 4:noxz]) / (12 * h)
    out1 = out_[:, 2:nox1 + 2]
    
    return out1




u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])
uy = load_var(Brek,'uy');
dudx = Brek['dudx_smooth'];
dudy = load_var(Brek,'dud_y');
duydx = Brek['duydx_smooth'];
dwdx = load_var(Brek,'dwd_x');
dwdy = load_var(Brek,'dwd_y');
a_x = load_var(Brek,'dudt_T_x');
a_y = load_var(Brek,'dudt_T_y');
dudt = Brek['du_dt_smooth'];
eta = load_var(Brek,'eta');

print('Data Loading success\n')

eta[:, :length_strp] = eta[:, id_s]
ux[:, :length_strp] = ux[:, id_s]
uy[:, :length_strp] = uy[:, id_s]
dudx[:, :length_strp] = dudx[:, id_s]
dudy[:, :length_strp] = dudy[:, id_s]
dudx[:, :length_strp] = dudx[:, id_s]
dudy[:, :length_strp] = dudy[:, id_s]
dwdx[:, :length_strp] = dwdx[:, id_s]
dwdy[:, :length_strp] = dwdy[:, id_s]
a_x[:, :length_strp] = a_x[:, id_s]
a_y[:, :length_strp] = a_y[:, id_s]

dt = t[1] - t[0]
dx = x[1] - x[0]
# eta_x = ps.SmoothedFiniteDifference(axis=1,smoother_kws={'window_length': 4})._differentiate(eta, t = -dx)
deta_dx = Brek['deta_dx_smooth'];
deta_dx2 = Brek['deta_dx2_smooth'];
# eta_t = ps.SmoothedFiniteDifference(axis=0,smoother_kws={'window_length': 4})._differentiate(eta, t = -dt)
eta_t = Brek['deta_dt_smooth'];
'''plt.figure()
plt.pcolormesh(t, x, eta_t)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.colorbar();
plt.figure()
diff = eta_x*ux+uy+uy*eta_x*eta_x-eta_t
plt.pcolormesh(t, x,diff)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.colorbar();
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''

residual=eta_t-(-ux*deta_dx+uy+uy*deta_dx*deta_dx)

# Assuming result and deta_dt are NumPy arrays
MSK = np.abs(residual) >= 0.04 * np.max(np.abs(residual))
MSK[:,0:300] = False;

# Remove elements from deta_dt where MSK is False


'''Tp = 1.34
f = 1 / Tp
k = np.sqrt(2 * np.pi * f / 9.81)

fig, axs = plt.subplots(1, 3, figsize=(15, 5))

# First Subplot
axs[0].imshow((eta_t[2:, 2:]).T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.8, vmax=0.8)
axs[0].set_xlim([-15*k, 0])
axs[0].set_ylim([0, 70/Tp])
axs[0].set_xlabel('$k_px$')
axs[0].set_ylabel('$t/T_p$')
axs[0].set_title('$\eta_t$')

# Second Subplot
RHS = (-ux * eta_x + uy + uy * eta_x * eta_x)
axs[1].imshow(RHS[2:, 2:].T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.8, vmax=0.8)
axs[1].set_xlim([-15*k, 0])
axs[1].set_ylim([0, 70/Tp])
axs[1].set_xlabel('$k_px$')
axs[1].set_ylabel('$t/T_p$')
axs[1].set_title('BSK-FNPF: $-\eta_x u+ w +w \eta_x \eta_x$')

# Third Subplot
result = eta_t - RHS
axs[2].imshow(result[2:, 2:].T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.7, vmax=0.7)
axs[2].set_xlim([-15*k, 0])
axs[2].set_ylim([0, 70/Tp])
axs[2].set_xlabel('$k_px$')
axs[2].set_ylabel('$t/T_p$')
axs[2].set_title('Diff')

plt.tight_layout()
plt.show()'''


eta_x_temp=deta_dx
eta_H = hilbert(eta, N=None, axis=0);
eta_H_x = hilbert(eta, N=None, axis=1);
num_data_points=eta_x_temp.shape[0]*eta_x_temp.shape[1]

u_in = np.zeros((eta_x_temp.shape[0]*eta_x_temp.shape[1], 15))

u_in [:,0] = np.reshape(deta_dx,num_data_points)
u_in [:,1] = np.reshape((uy),num_data_points)
u_in [:,2] = np.reshape((ux),num_data_points)
u_in [:,3] = np.reshape((dudx),num_data_points)
u_in [:,4] = np.reshape((dudy),num_data_points)
u_in [:,5] = np.reshape((dwdx),num_data_points)
u_in [:,6] = np.reshape((dwdy),num_data_points)
u_in [:,7] = np.reshape((a_x),num_data_points)
u_in [:,8] = np.reshape((a_y),num_data_points)
u_in [:,9] = np.reshape((deta_dx2),num_data_points)
u_in [:,10] = np.reshape((eta),num_data_points)
u_in [:,11] = np.reshape((eta_H.imag),num_data_points)
u_in [:,12] = np.reshape((eta_H_x.imag),num_data_points)
u_in [:,13] = np.reshape(abs(eta_H),num_data_points)
u_in [:,14] = np.reshape(abs(eta_H_x),num_data_points)

print('Data Preprocessing success\n')

tar_eta_t = np.reshape(MSK,num_data_points)
model_real = pysr.PySRRegressor(binary_operators=["+", "*", "/"],
                                complexity_of_operators={"*": 10}, 
                                maxsize = 50, 
                                batching=True,
                                populations=50,
                                ncyclesperiteration = 5000,
                                procs = 16,
                                )
model_real.fit(u_in,np.real(tar_eta_t))
print('The classfication is \n')
print(model_real.get_best().equation)



# Plot u and u_dot
'''plt.figure()
plt.pcolormesh(t, x, u)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.figure()

plt.pcolormesh(t, x, u_dot)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''
