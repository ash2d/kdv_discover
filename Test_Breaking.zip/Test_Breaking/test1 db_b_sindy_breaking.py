import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp
 
import units as u
import pysindy as ps
import pysr
from scipy.ndimage import gaussian_filter, convolve

# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Seed the random number generators for reproducibility
# np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
Brek = loadmat('/data/Dropbox/MATLAB_for_Baslisk/test_BK_0d23_1d34_bak_surf2')
x = np.ravel(Brek['x1'])
time_wrong = np.ravel(Brek['time_vec'])

t = np.linspace(0,time_wrong[-1],len(time_wrong))



def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u1 = np.real(u_nested[0][0])
    return u1

def grad1(in1, h):
    """
    This function takes the gradient in the x direction. h is the spatial step.
    """
    out1 = np.zeros_like(in1)
    noy1, nox1 = in1.shape
    in_ = np.zeros((noy1, nox1 + 4))
    noyz, noxz = in_.shape
    
    in_[:, 0] = in1[:, nox1 - 2]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 1] = in1[:, nox1 - 1]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 2:nox1 + 2] = in1
    in_[:, noxz - 2] = in_[:, 1]
    in_[:, noxz - 1] = in_[:, 0]
    
    out_ = np.zeros_like(in_)
    out_[:, 2:noxz - 2] = (-in_[:, 0:noxz - 4] + 8 * in_[:, 1:noxz - 3] - 8 * in_[:, 3:noxz - 1] + in_[:, 4:noxz]) / (12 * h)
    out1 = out_[:, 2:nox1 + 2]
    
    return out1


u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])
uy = load_var(Brek,'uy');
dudx = Brek['dudx'];
dudy = load_var(Brek,'dud_y');
duydx = Brek['duydx'];
dwdy = load_var(Brek,'dwd_y');
a_x = load_var(Brek,'dudt_T_x');
a_y = load_var(Brek,'dudt_T_y');
dudt = Brek['du_dt'];
eta = load_var(Brek,'eta');


print('Data Loading success\n')



dt = t[1] - t[0]
dx = x[1] - x[0]
# eta_x = ps.SmoothedFiniteDifference(axis=1,smoother_kws={'window_length': 4})._differentiate(eta, t = -dx)
deta_dx = Brek['deta_dx'];

deta_dx2 = Brek['deta_dx2'];

# eta_t = ps.SmoothedFiniteDifference(axis=0,smoother_kws={'window_length': 4})._differentiate(eta, t = -dt)
'''plt.figure()
plt.pcolormesh(t, x, eta_t)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.colorbar();
plt.figure()
diff = eta_x*ux+uy+uy*eta_x*eta_x-eta_t
plt.pcolormesh(t, x,diff)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.colorbar();
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''
RHS=-9.81 * deta_dx - dudx *ux - (duydx*uy)- uy * duydx * deta_dx**2 - uy**2 * deta_dx * deta_dx2
cbar_min = -5
cbar_max = 5

residual = dudt - RHS

MSK = residual >= 0.01 * np.max(residual)
MSK[:,0:300] = False
weight = residual*0
weight = np.where(MSK, 1, 0.001)



'''plt.figure()
plt.pcolormesh(t, x, MSK)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.colorbar();
plt.show()'''
# Assuming result and deta_dt are NumPy arrays

# Remove elements from deta_dt where MSK is False


'''Tp = 1.34
f = 1 / Tp
k = np.sqrt(2 * np.pi * f / 9.81)

fig, axs = plt.subplots(1, 3, figsize=(15, 5))

# First Subplot
axs[0].imshow((eta_t[2:, 2:]).T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.8, vmax=0.8)
axs[0].set_xlim([-15*k, 0])
axs[0].set_ylim([0, 70/Tp])
axs[0].set_xlabel('$k_px$')
axs[0].set_ylabel('$t/T_p$')
axs[0].set_title('$\eta_t$')

# Second Subplot
RHS = (-ux * eta_x + uy + uy * eta_x * eta_x)
axs[1].imshow(RHS[2:, 2:].T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.8, vmax=0.8)
axs[1].set_xlim([-15*k, 0])
axs[1].set_ylim([0, 70/Tp])
axs[1].set_xlabel('$k_px$')
axs[1].set_ylabel('$t/T_p$')
axs[1].set_title('BSK-FNPF: $-\eta_x u+ w +w \eta_x \eta_x$')

# Third Subplot
result = eta_t - RHS
axs[2].imshow(result[2:, 2:].T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.7, vmax=0.7)
axs[2].set_xlim([-15*k, 0])
axs[2].set_ylim([0, 70/Tp])
axs[2].set_xlabel('$k_px$')
axs[2].set_ylabel('$t/T_p$')
axs[2].set_title('Diff')

plt.tight_layout()
plt.show()'''




u_in = np.zeros((uy.shape[0],len(time_wrong[451:-1]), 4))
u_in [:,:,0] = eta[:,451:-1]
u_in [:,:,1] = ux[:,451:-1]
u_in [:,:,2] = uy[:,451:-1]
u_in [:,:,3] = RHS[:,451:-1]

print('Data Preprocessing success\n')

feature_names = [" eta", " ux", " uy" ,'FNPF'];

library_functions = [lambda x: x, lambda x, y: x * y , lambda x, y: x * y * y]
library_function_names = [lambda x: x , lambda  x, y: x + y , lambda  x, y: x + y + y]
pde_lib_single_terms = ps.PDELibrary(
    library_functions=library_functions,
    function_names=library_function_names,
    derivative_order=1,
    spatial_grid=x,
    is_uniform=True,
).fit([u_in])

print("Original input library: ")
print(pde_lib_single_terms.get_feature_names())


pde_lib=pde_lib_single_terms


print('STLSQ model: ')
optimizer = ps.STLSQ(threshold=2, alpha=1e-5, normalize_columns=True)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SR3 model, L0 norm: ')
optimizer = ps.SR3(
    threshold=2,
    max_iter=10000,
    tol=1e-15,
    nu=1e2,
    thresholder="l0",
    normalize_columns=True,
)

model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SR3 model, L1 norm: ')
optimizer = ps.SR3(
    threshold=0.5, max_iter=10000, tol=1e-15,
    thresholder="l1", normalize_columns=True
)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SSR model: ')
optimizer = ps.SSR(normalize_columns=True, kappa=1)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SSR (metric = model residual) model: ')
optimizer = ps.SSR(criteria="model_residual",
                   normalize_columns=True,
                   kappa=1)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('FROLs model: ')
optimizer = ps.FROLS(normalize_columns=True, kappa=1e-3)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

