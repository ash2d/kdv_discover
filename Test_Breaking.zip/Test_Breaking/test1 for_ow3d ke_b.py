import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp
import mat73

import pysindy as ps
import h5py

def read_v73(file_path, variable_name):
    """
    Reads a single specified variable from a .mat file in v7.3 format.

    Parameters:
        file_path (str): The path to the .mat file.
        variable_name (str): The name of the variable to read from the .mat file.

    Returns:
        np.ndarray: A NumPy array containing the data of the specified variable.
    """
    with h5py.File(file_path, 'r') as f:
        if variable_name in f.keys():
            # Read the data and convert it to a NumPy array
            data = np.array(f[variable_name])
            return data
        else:
            print(f"Warning: {variable_name} not found in {file_path}")
            return None

# Example usage
file_path = "/data/OW3D_Ke/test_WG_0d24_1d25_Ke_1.mat"



# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Seed the random number generators for reproducibility
np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
# Brek = mat73.loadmat('/data/OW3D_Ke/test_WG_0d24_1d25_Ke_1.mat')
t = read_v73(file_path, 't_out')
t = np.reshape(t,(len(t)))
x = read_v73(file_path, 'x')
x = np.reshape(x,(x.shape[1]))

ux = read_v73(file_path, 'u_m')
ux = ux[:,60,:]
uy = read_v73(file_path, 'w_m')
uy = uy[:,60,:]

eta = read_v73(file_path, 'eta_m')



'''dudx = load_var(Brek,'dud_x');
dudy = load_var(Brek,'dud_y');
uy = load_var(Brek,'uy');
dudx = load_var(Brek,'dud_x');
dudy = load_var(Brek,'dud_y');
dwdx = load_var(Brek,'dwd_x');
dwdy = load_var(Brek,'dwd_y');
eta = load_var(Brek,'eta');'''
# print(x)

'''import numpy as np
from pysindy.differentiation import FiniteDifference
t = np.linspace(0, 1, 5)
X = np.vstack((np.sin(t), np.cos(t))).T
fd = FiniteDifference()
ARRA1 = fd._differentiate(X, t)'''


dt = t[1] - t[0]
dx = x[1] - x[0]
eta_x=ps.FiniteDifference(axis=0)._differentiate(eta, t=dx)
u_in = np.zeros((uy.shape[0],uy.shape[1], 4))
u_in [:,:,0] = eta_x*ux
u_in [:,:,1] = uy
u_in [:,:,2] = uy*eta_x*eta_x
u_in [:,:,3] = eta




# Plot u and u_dot
'''plt.figure()
plt.pcolormesh(t, x, u)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.figure()

plt.pcolormesh(t, x, u_dot)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''


# u = ux.reshape(len(x), len(t), 1)
# u_dot = u_dot.reshape(len(x), len(t), 1)

feature_names = [" eta_x ux", " uy", " uy eta_x eta_x" ,"eta"];

library_functions = [lambda x: x, ]
library_function_names = [lambda x: x ]
pde_lib_single_terms = ps.PDELibrary(
    library_functions=library_functions,
    function_names=library_function_names,
    derivative_order=0,
    is_uniform=True,
).fit([u_in])

print("Original input library: ")
print(pde_lib_single_terms.get_feature_names())


pde_lib=pde_lib_single_terms


'''print('STLSQ model: ')
optimizer = ps.STLSQ(threshold=2, alpha=1e-5, normalize_columns=True)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SR3 model, L0 norm: ')
optimizer = ps.SR3(
    threshold=2,
    max_iter=10000,
    tol=1e-15,
    nu=1e2,
    thresholder="l0",
    normalize_columns=True,
)

model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SR3 model, L1 norm: ')
optimizer = ps.SR3(
    threshold=0.5, max_iter=10000, tol=1e-15,
    thresholder="l1", normalize_columns=True
)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

print('SSR model: ')
optimizer = ps.SSR(normalize_columns=True, kappa=1)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()'''

print('SSR (metric = model residual) model: ')
optimizer = ps.SSR(criteria="model_residual",
                   normalize_columns=True,
                   kappa=5)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()

'''print('FROLs model: ')
optimizer = ps.FROLS(normalize_columns=True, kappa=1e-3)
model = ps.SINDy(feature_library=pde_lib, optimizer=optimizer,feature_names=feature_names)
model.fit(u_in, t=dt)
model.print()'''


