import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp
 
import units as u
import pysindy as ps
import pysr

# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Seed the random number generators for reproducibility
# np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
Brek = loadmat('/data/Dropbox/MATLAB_for_Baslisk/test_BK_0d23_1d34_bak_surf1')
x = np.ravel(Brek['x1'])
time_wrong = np.ravel(Brek['time_vec'])
length_strp = len(time_wrong)
id_s = np.argsort(time_wrong[:length_strp])

t = np.linspace(0,time_wrong[-1],len(time_wrong))

u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])


def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u1 = np.real(u_nested[0][0])
    return u1
def grad1(in1, h):
    """
    This function takes the gradient in the x direction. h is the spatial step.
    """
    out1 = np.zeros_like(in1)
    noy1, nox1 = in1.shape
    in_ = np.zeros((noy1, nox1 + 4))
    noyz, noxz = in_.shape
    
    in_[:, 0] = in1[:, nox1 - 2]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 1] = in1[:, nox1 - 1]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 2:nox1 + 2] = in1
    in_[:, noxz - 2] = in_[:, 1]
    in_[:, noxz - 1] = in_[:, 0]
    
    out_ = np.zeros_like(in_)
    out_[:, 2:noxz - 2] = (-in_[:, 0:noxz - 4] + 8 * in_[:, 1:noxz - 3] - 8 * in_[:, 3:noxz - 1] + in_[:, 4:noxz]) / (12 * h)
    out1 = out_[:, 2:nox1 + 2]
    
    return out1



uy = load_var(Brek,'uy');
dudx = load_var(Brek,'dud_x');
dudy = load_var(Brek,'dud_y');
dudx = load_var(Brek,'dud_x');
dudy = load_var(Brek,'dud_y');
dwdx = load_var(Brek,'dwd_x');
dwdy = load_var(Brek,'dwd_y');
a_x = load_var(Brek,'dudt_T_x');
a_y = load_var(Brek,'dudt_T_y');

eta = load_var(Brek,'eta');

eta[:, :length_strp] = eta[:, id_s]
ux[:, :length_strp] = ux[:, id_s]
uy[:, :length_strp] = uy[:, id_s]
dudx[:, :length_strp] = dudx[:, id_s]
dudy[:, :length_strp] = dudy[:, id_s]
dudx[:, :length_strp] = dudx[:, id_s]
dudy[:, :length_strp] = dudy[:, id_s]
dwdx[:, :length_strp] = dwdx[:, id_s]
dwdy[:, :length_strp] = dwdy[:, id_s]
a_x[:, :length_strp] = a_x[:, id_s]
a_y[:, :length_strp] = a_y[:, id_s]

dt = t[1] - t[0]
dx = x[1] - x[0]
# eta_x = ps.SmoothedFiniteDifference(axis=1,smoother_kws={'window_length': 4})._differentiate(eta, t = -dx)
eta_x = - grad1(eta.T,dx)
eta_x = eta_x.T
# eta_t = ps.SmoothedFiniteDifference(axis=0,smoother_kws={'window_length': 4})._differentiate(eta, t = -dt)
eta_t = - grad1(eta,dt)
'''plt.figure()
plt.pcolormesh(t, x, eta_t)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.colorbar();
plt.figure()
diff = eta_x*ux+uy+uy*eta_x*eta_x-eta_t
plt.pcolormesh(t, x,diff)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.colorbar();
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''

residual=eta_t-(-ux*eta_x+uy+uy*eta_x*eta_x)



'''Tp = 1.34
f = 1 / Tp
k = np.sqrt(2 * np.pi * f / 9.81)

fig, axs = plt.subplots(1, 3, figsize=(15, 5))

# First Subplot
axs[0].imshow((eta_t[2:, 2:]).T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.8, vmax=0.8)
axs[0].set_xlim([-15*k, 0])
axs[0].set_ylim([0, 70/Tp])
axs[0].set_xlabel('$k_px$')
axs[0].set_ylabel('$t/T_p$')
axs[0].set_title('$\eta_t$')

# Second Subplot
RHS = (-ux * eta_x + uy + uy * eta_x * eta_x)
axs[1].imshow(RHS[2:, 2:].T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.8, vmax=0.8)
axs[1].set_xlim([-15*k, 0])
axs[1].set_ylim([0, 70/Tp])
axs[1].set_xlabel('$k_px$')
axs[1].set_ylabel('$t/T_p$')
axs[1].set_title('BSK-FNPF: $-\eta_x u+ w +w \eta_x \eta_x$')

# Third Subplot
result = eta_t - RHS
axs[2].imshow(result[2:, 2:].T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.7, vmax=0.7)
axs[2].set_xlim([-15*k, 0])
axs[2].set_ylim([0, 70/Tp])
axs[2].set_xlabel('$k_px$')
axs[2].set_ylabel('$t/T_p$')
axs[2].set_title('Diff')

plt.tight_layout()
plt.show()'''


num_data_points=eta_x.shape[0]*len(time_wrong[451:-1])


u_in = np.zeros((num_data_points, 9))
u_in [:,0] = np.reshape((eta_x[:,451:-1]),num_data_points)
u_in [:,1] = np.reshape((uy[:,451:-1]),num_data_points)
u_in [:,2] = np.reshape((ux[:,451:-1]),num_data_points)
u_in [:,3] = np.reshape((dudx[:,451:-1]),num_data_points)
u_in [:,4] = np.reshape((dudy[:,451:-1]),num_data_points)
u_in [:,5] = np.reshape((dwdx[:,451:-1]),num_data_points)
u_in [:,6] = np.reshape((dwdy[:,451:-1]),num_data_points)
u_in [:,7] = np.reshape((a_x[:,451:-1]),num_data_points)
u_in [:,8] = np.reshape((a_y[:,451:-1]),num_data_points)
tar_eta_t = np.reshape(residual[:,451:-1],num_data_points)
model_real = pysr.PySRRegressor(binary_operators=["+", "*"],
                                complexity_of_operators={"*": 4}, 
                                maxsize = 17, 
                                batching=True,
                                dimensional_constraint_penalty=10**5,
                                )
model_real.fit(u_in,np.real(tar_eta_t),X_units= ["1","m/s","m/s"," 1/s"," 1/s"," 1/s"," 1/s"," m/s^2"," m/s^2"], y_units= ["m/s"])
print(model_real)



# Plot u and u_dot
'''plt.figure()
plt.pcolormesh(t, x, u)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.figure()

plt.pcolormesh(t, x, u_dot)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''
