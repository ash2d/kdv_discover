import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp
 
import units as u
import pysindy as ps
import pysr
from scipy.ndimage import gaussian_filter, convolve

# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Seed the random number generators for reproducibility
# np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
Brek = loadmat('/data/Dropbox/MATLAB_for_Baslisk/test_BK_0d23_1d42_bak_surf3_pert')
x = np.ravel(Brek['x1'])
time_wrong = np.ravel(Brek['time_vec'])

t = np.linspace(0,time_wrong[-1],len(time_wrong))



def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u1 = np.real(u_nested[0][0])
    return u1

def grad1(in1, h):
    """
    This function takes the gradient in the x direction. h is the spatial step.
    """
    out1 = np.zeros_like(in1)
    noy1, nox1 = in1.shape
    in_ = np.zeros((noy1, nox1 + 4))
    noyz, noxz = in_.shape
    
    in_[:, 0] = in1[:, nox1 - 2]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 1] = in1[:, nox1 - 1]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 2:nox1 + 2] = in1
    in_[:, noxz - 2] = in_[:, 1]
    in_[:, noxz - 1] = in_[:, 0]
    
    out_ = np.zeros_like(in_)
    out_[:, 2:noxz - 2] = (-in_[:, 0:noxz - 4] + 8 * in_[:, 1:noxz - 3] - 8 * in_[:, 3:noxz - 1] + in_[:, 4:noxz]) / (12 * h)
    out1 = out_[:, 2:nox1 + 2]
    
    return out1


u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])
uy = load_var(Brek,'uy');
dudx = Brek['dudx_smooth'];
dudy = load_var(Brek,'dud_y');
duydx = Brek['duydx_smooth'];
dwdy = load_var(Brek,'dwd_y');
a_x = load_var(Brek,'dudt_T_x');
a_y = load_var(Brek,'dudt_T_y');
dudt = Brek['du_dt_smooth'];
eta = load_var(Brek,'eta');


print('Data Loading success\n')



dt = t[1] - t[0]
dx = x[1] - x[0]
# eta_x = ps.SmoothedFiniteDifference(axis=1,smoother_kws={'window_length': 4})._differentiate(eta, t = -dx)
deta_dx = Brek['deta_dx_smooth'];

deta_dx2 = Brek['deta_dx2_smooth'];
eta_t = Brek['deta_dt_smooth'];
# eta_t = ps.SmoothedFiniteDifference(axis=0,smoother_kws={'window_length': 4})._differentiate(eta, t = -dt)
'''plt.figure()
plt.pcolormesh(t, x, eta_t)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.colorbar();
plt.figure()
diff = eta_x*ux+uy+uy*eta_x*eta_x-eta_t
plt.pcolormesh(t, x,diff)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.colorbar();
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''
RHS=-9.81 * deta_dx - dudx *ux - (duydx*uy)- uy * duydx * deta_dx**2 - uy**2 * deta_dx * deta_dx2
cbar_min = -5
cbar_max = 5

residual = dudt - RHS

MSK = np.abs(residual) >= 0.04 * np.max(np.abs(residual))
MSK[:,0:300] = False;
'''plt.figure()
plt.pcolormesh(t, x, MSK)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.colorbar();
plt.show()'''
# Assuming result and deta_dt are NumPy arrays

# Remove elements from deta_dt where MSK is False


'''Tp = 1.34
f = 1 / Tp
k = np.sqrt(2 * np.pi * f / 9.81)

fig, axs = plt.subplots(1, 3, figsize=(15, 5))

# First Subplot
axs[0].imshow((eta_t[2:, 2:]).T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.8, vmax=0.8)
axs[0].set_xlim([-15*k, 0])
axs[0].set_ylim([0, 70/Tp])
axs[0].set_xlabel('$k_px$')
axs[0].set_ylabel('$t/T_p$')
axs[0].set_title('$\eta_t$')

# Second Subplot
RHS = (-ux * eta_x + uy + uy * eta_x * eta_x)
axs[1].imshow(RHS[2:, 2:].T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.8, vmax=0.8)
axs[1].set_xlim([-15*k, 0])
axs[1].set_ylim([0, 70/Tp])
axs[1].set_xlabel('$k_px$')
axs[1].set_ylabel('$t/T_p$')
axs[1].set_title('BSK-FNPF: $-\eta_x u+ w +w \eta_x \eta_x$')

# Third Subplot
result = eta_t - RHS
axs[2].imshow(result[2:, 2:].T, aspect='auto', origin='lower', extent=[-15*k, 0, 0, 70/Tp], cmap="jet", vmin=-0.7, vmax=0.7)
axs[2].set_xlim([-15*k, 0])
axs[2].set_ylim([0, 70/Tp])
axs[2].set_xlabel('$k_px$')
axs[2].set_ylabel('$t/T_p$')
axs[2].set_title('Diff')

plt.tight_layout()
plt.show()'''

eta_x_temp=deta_dx[MSK]


num_data_points=eta_x_temp.shape[0]

u_in = np.zeros((num_data_points, 10))

u_in [:,0] = np.reshape(deta_dx[MSK],num_data_points)
u_in [:,1] = np.reshape((uy[MSK]),num_data_points)
u_in [:,2] = np.reshape((ux[MSK]),num_data_points)
u_in [:,3] = np.reshape((dudx[MSK]),num_data_points)
u_in [:,4] = np.reshape((dudy[MSK]),num_data_points)
u_in [:,5] = np.reshape((duydx[MSK]),num_data_points)
u_in [:,6] = np.reshape((dwdy[MSK]),num_data_points)
u_in [:,7] = np.reshape((duydx[MSK]),num_data_points)
u_in [:,8] = np.reshape((deta_dx2[MSK]),num_data_points)
u_in [:,9] = np.reshape((deta_dx2[MSK]*0+9.81),num_data_points)

print('Data Preprocessing success\n')

tar_eta_t = np.reshape(residual[MSK],num_data_points)
model_real = pysr.PySRRegressor(binary_operators=["+", "*"],
                                complexity_of_operators={"*": 7}, 
                                maxsize = 55, 
                                batching=True,
                                dimensional_constraint_penalty=10**4,
                                populations=45,
                                ncyclesperiteration = 5000,
                                )
model_real.fit(u_in,np.real(tar_eta_t),X_units= ["1","m/s","m/s"," 1/s"," 1/s"," 1/s"," 1/s"," m/s^2"," 1 / m "," m/s^2"], y_units= ["m/s^2"])
print('Db_boundary is \n')
print(model_real.get_best().equation)



# Plot u and u_dot
'''plt.figure()
plt.pcolormesh(t, x, u)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.figure()

plt.pcolormesh(t, x, u_dot)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''
