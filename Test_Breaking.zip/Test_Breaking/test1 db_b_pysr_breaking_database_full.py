import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from sklearn.linear_model import Lasso
from scipy.io import loadmat
from sklearn.metrics import mean_squared_error
from scipy.integrate import solve_ivp
 
import units as u
import pysindy as ps
import pysr
from scipy.ndimage import gaussian_filter, convolve
from scipy.signal import hilbert, chirp

# Ignore matplotlib deprecation warnings
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Seed the random number generators for reproducibility
# np.random.seed(100)

integrator_keywords = {}
integrator_keywords['rtol'] = 1e-12
integrator_keywords['method'] = 'LSODA'
integrator_keywords['atol'] = 1e-12

# Load the data stored in a matlab .mat file
Brek = loadmat('/data/Dropbox/MATLAB_for_Baslisk/db_database_full_271023.mat')
x = np.ravel(Brek['x1'])
time_wrong = np.ravel(Brek['time_vec'])
length_strp = len(time_wrong)
id_s = np.argsort(time_wrong[:length_strp])

t = np.linspace(0,time_wrong[-1],len(time_wrong))

u_nested = Brek['sfr']['ux']
ux = np.real(u_nested[0][0])
T = 1.091;
omega= 2*np.pi/T;

def load_var(Brek,varname):
    u_nested = Brek['sfr'][varname]
    u1 = np.real(u_nested[0][0])
    return u1
def grad1(in1, h):
    """
    This function takes the gradient in the x direction. h is the spatial step.
    """
    out1 = np.zeros_like(in1)
    noy1, nox1 = in1.shape
    in_ = np.zeros((noy1, nox1 + 4))
    noyz, noxz = in_.shape
    
    in_[:, 0] = in1[:, nox1 - 2]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 1] = in1[:, nox1 - 1]  # Adjusted index by -1 for 0-based indexing in Python
    in_[:, 2:nox1 + 2] = in1
    in_[:, noxz - 2] = in_[:, 1]
    in_[:, noxz - 1] = in_[:, 0]
    
    out_ = np.zeros_like(in_)
    out_[:, 2:noxz - 2] = (-in_[:, 0:noxz - 4] + 8 * in_[:, 1:noxz - 3] - 8 * in_[:, 3:noxz - 1] + in_[:, 4:noxz]) / (12 * h)
    out1 = out_[:, 2:nox1 + 2]
    
    return out1





u_in = Brek['u_in'];

tar_eta_t = Brek['tar_eta_full'];
tar_eta_t = tar_eta_t.reshape((u_in.shape[0], 1));
print('Data Loading and success\n')

model_real = pysr.PySRRegressor(binary_operators=["+", "*"],
                                complexity_of_operators={"*": 8}, 
                                maxsize = 35, 
                                batching=True,
                                dimensional_constraint_penalty=10**5,
                                populations=155,
                                ncyclesperiteration = 5000,
                                model_selection='accuracy',
                                )
model_real.fit(u_in,np.real(tar_eta_t),X_units= ["1","m/s","m/s"," 1/s"," 1/s"," 1/s"," 1/s"," 1 / m ", " m " , " m ",  "  m " , " m ", " m ", " 1/s ", " 1/m "], y_units= ["m/s"])
print('DATABASE_Train: Db_boundary in full is \n')
print(model_real.get_best().equation)



# Plot u and u_dot
'''plt.figure()
plt.pcolormesh(t, x, u)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$u(x, t)$', fontsize=16)
plt.figure()

plt.pcolormesh(t, x, u_dot)
plt.xlabel('t', fontsize=16)
plt.ylabel('x', fontsize=16)
plt.title(r'$\dot{u}(x, t)$', fontsize=16)
plt.show()'''
